"use client";

import { useEffect, useRef, useState } from "react";
import { Icon } from "@iconify/react";
import type { Profile } from "../../../types/profile";
import { useThemeStore } from "../../../store/useThemeStore";
import { SearchStyleInput } from "../../ui/Input";
import { Checkbox } from "../../ui/Checkbox";
import { gsap } from "gsap";
import { ProfileIcon } from "../ProfileIcon";
import { useMinecraftAuthStore } from "../../../store/minecraft-auth-store";
import { usePlayerAvatar } from "../../../hooks/usePlayerAvatar";
import type { MinecraftAccount } from "../../../types/minecraft";
import { cn } from "../../../lib/utils";
import { useTranslation } from "react-i18next";
import { writeText } from "@tauri-apps/plugin-clipboard-manager";
import { toast } from "react-hot-toast";

interface GeneralSettingsTabProps {
  profile: Profile;
  editedProfile: Profile;
  updateProfile: (updates: Partial<Profile>) => void;
  onRefresh?: () => Promise<Profile>;
  onDelete?: () => void;
  isDeleting?: boolean;
}



export function GeneralSettingsTab({
  profile,
  editedProfile,
  updateProfile,
  onRefresh,
  onDelete,
  isDeleting,
}: GeneralSettingsTabProps) {
  const { t } = useTranslation();
  const accentColor = useThemeStore((state) => state.accentColor);
  const isBackgroundAnimationEnabled = useThemeStore(
    (state) => state.isBackgroundAnimationEnabled,
  );
  const tabRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);
  const { accounts } = useMinecraftAuthStore();

  useEffect(() => {
    if (isBackgroundAnimationEnabled) {
      if (tabRef.current) {
        gsap.fromTo(
          tabRef.current,
          { opacity: 0 },
          { opacity: 1, duration: 0.4, ease: "power2.out" },
        );
      }

      if (formRef.current) {
        gsap.fromTo(
          formRef.current.children,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.4,
            stagger: 0.1,
            ease: "power2.out",
            delay: 0.2,
          },
        );
      }


    }
  }, [isBackgroundAnimationEnabled]);

  // Component for account avatar with caching
  function AccountAvatar({ account }: { account: MinecraftAccount }) {
    const avatarUrl = usePlayerAvatar({
      uuid: account.id,
      overlay: true,
    });

    if (!avatarUrl) {
      return null;
    }

    return (
      <img
        src={avatarUrl}
        alt={account.username}
        className="w-full h-full object-cover pixelated"
        style={{ imageRendering: 'pixelated' }}
        onError={(e) => {
          e.currentTarget.style.display = 'none';
        }}
      />
    );
  }

  const handleAccountSelect = (accountId: string | null) => {
    updateProfile({ preferred_account_id: accountId });
  };

  const handleCopyProfileId = async () => {
    try {
      await writeText(profile.id);
      toast.success(t('profiles.settings.profileIdCopied'));
    } catch (e) {
      console.error("Failed to copy profile ID:", e);
    }
  };

  return (
    <div ref={tabRef} className="space-y-6 select-none">
      <div ref={formRef} className="space-y-6">
        <div className="flex gap-6">
          <div className="flex-1 flex flex-col">
            <label className="block text-lg font-smallcaps text-white mb-2">
              {t('profiles.settings.profileName')}
            </label>
            <div className="flex items-center gap-4">
              <ProfileIcon
                profileId={profile.id}
                banner={profile.banner}
                profileName={profile.name}
                accentColor={accentColor.value}
                onSuccessfulUpdate={async () => {
                  try {
                    if (onRefresh) {
                      await onRefresh();
                    }
                  } catch (error) {
                    console.error("Failed to refresh profile after icon update:", error);
                  }
                }}
                className="w-12 h-12 flex-shrink-0"
              />
              <SearchStyleInput
                value={editedProfile.name}
                onChange={(e) => updateProfile({ name: e.target.value })}
                placeholder={t('profiles.settings.enterProfileName')}
                className="text-sm flex-1"
                disabled={profile.is_standard_version ? true : false}
              />
            </div>
          </div>

          <div className="flex-1 flex flex-col">
            <label className="block text-lg font-smallcaps text-white mb-2">
              {t('profiles.settings.group')}
            </label>
            <div className="flex items-center">
              <SearchStyleInput
                value={editedProfile.group || ""}
                onChange={(e) => updateProfile({ group: e.target.value || null })}
                placeholder={t('placeholders.group_name')}
                className="text-sm w-full"
                disabled={profile.is_standard_version ? true : false}
              />
            </div>
          </div>
        </div>

        {/* Shared Minecraft Folder Checkbox */}
        <div className="space-y-1">
          <Checkbox
            label={t('profiles.settings.useSharedFolder')}
            checked={editedProfile.use_shared_minecraft_folder ?? false}
            onChange={(event) => {
              const newValue = event.target.checked;
              updateProfile({
                use_shared_minecraft_folder: newValue
              });
            }}
            description={t('profiles.settings.sharedFolderDescription')}
            descriptionClassName="font-minecraft text-sm"
            size="lg"
          />
          <p className="text-xs text-white/50 font-minecraft ml-10 -mt-1">
            {t('profiles.settings.canChangeAnytime')}
          </p>
        </div>

        <div>
          <label className="block text-lg font-smallcaps text-white mb-2">
            {t('profiles.settings.quickPlayPath')}
          </label>
          <SearchStyleInput
            value={editedProfile.settings.quick_play_path || ""}
            onChange={(e) =>
              updateProfile({
                settings: {
                  ...editedProfile.settings,
                  quick_play_path: e.target.value || null
                }
              })
            }
            placeholder={t('profiles.settings.quickPlayPlaceholder')}
            className="text-sm"
          />
          <p className="text-xs text-white/70 mt-2 font-minecraft tracking-wide select-none">
            {t('profiles.settings.quickPlayDescription')}
          </p>
        </div>

        <div ref={accountRef} className="space-y-3">
          <h3 className="text-lg font-smallcaps text-white">
            {t('profiles.settings.preferredAccount')}
          </h3>
          
          {accounts.length > 0 ? (
            <div className="flex flex-wrap gap-3 p-1">
              {accounts.map((account) => {
                const isSelected = editedProfile.preferred_account_id === account.id;
                
                return (
                  <button
                    key={account.id}
                    onClick={() => handleAccountSelect(isSelected ? null : account.id)}
                    className={cn(
                      "relative group flex flex-col items-center p-3 border-2 transition-all duration-200 rounded-lg hover:scale-105",
                      isSelected
                        ? "border-accent shadow-lg"
                        : "border-white/10 hover:border-white/30",
                    )}
                    style={
                      isSelected
                        ? {
                            borderColor: accentColor.value,
                            backgroundColor: `${accentColor.value}15`,
                          }
                        : {}
                    }
                    title={`${account.username} (${account.id})`}
                  >
                    {/* Player Head */}
                    <div className={cn(
                      "relative w-16 h-16 rounded-md overflow-hidden border-2 transition-all duration-200",
                      isSelected ? "border-accent" : "border-white/20"
                    )}
                    style={isSelected ? { borderColor: accentColor.value } : {}}>
                      <AccountAvatar account={account} />
                      {isSelected && (
                        <div 
                          className="absolute inset-0 flex items-center justify-center bg-black/50"
                        >
                          <Icon
                            icon="solar:check-circle-bold"
                            className="w-8 h-8"
                            style={{ color: accentColor.value }}
                          />
                        </div>
                      )}
                    </div>
                    
                    {/* Username */}
                    <div className={cn(
                      "mt-2 font-smallcaps text-sm text-center max-w-[100px] truncate",
                      isSelected ? "text-white" : "text-white/70"
                    )}>
                      {account.username}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-4 text-white/50 font-smallcaps text-xs">
              {t('profiles.settings.noAccountsFound')}
            </div>
          )}
        </div>

        {/* Profile ID — discreet, click to copy */}
        <div className="pt-4 mt-2 border-t border-white/10">
          <button
            type="button"
            onClick={handleCopyProfileId}
            title={t('profiles.settings.copyProfileId')}
            className="group flex items-center gap-1.5 text-white/30 hover:text-white/55 transition-colors"
          >
            <Icon icon="solar:copy-linear" className="w-3.5 h-3.5" />
            <span className="font-minecraft text-xs tracking-wide">
              {profile.id}
            </span>
          </button>
        </div>

      </div>


    </div>
  );
}
