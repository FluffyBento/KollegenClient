// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(
    all(not(debug_assertions), target_os = "windows"),
    windows_subsystem = "windows"
)]

use noriskclient_launcher_v3_lib::*;
use noriskclient_launcher_v3_lib::{cli, commands, logging, state, utils};

use log::{error, info, trace};
use std::sync::Arc;
use tauri::Listener;
use tauri::Manager;
use tauri_plugin_deep_link::DeepLinkExt;
use utils::updater_utils;

use crate::commands::analytics_command::track_analytics_event;
use crate::commands::font_command::list_system_fonts;
use crate::commands::process_command::{
    fetch_crash_report, focus_main_window, get_process, get_process_log_cursor,
    get_processes, get_processes_by_profile, open_minecraft_log_window, open_single_log_window,
    set_discord_state, stop_process,
};
use commands::minecraft_auth_command::{
    begin_login, cancel_login, get_accounts, get_active_account, is_flatpak, remove_account, set_active_account
};
use commands::minecraft_command::{
    add_skin,
    apply_skin_from_base64,
    get_active_skin,
    // Local skin database commands
    get_all_skins,
    get_fabric_loader_versions,
    get_forge_versions,
    get_minecraft_versions,
    get_neoforge_versions,
    get_quilt_loader_versions,
    get_skin_by_id,
    // Skin management commands
    get_user_skin_data,
    ping_minecraft_server,
    remove_skin,
    reset_skin,
    update_skin_properties,
    upload_log_to_mclogs_command,
    upload_skin,
};
use commands::profile_command::{
    abort_profile_launch, add_modrinth_content_to_profile, add_modrinth_mod_to_profile,
    batch_check_content_installed, check_for_group_migration_command, check_world_lock_status, copy_profile, copy_world,
    create_profile, delete_custom_mod, delete_mod_from_profile, delete_profile, delete_world,
    export_profile, get_all_profiles_and_last_played, get_custom_mods, get_local_content,
    get_local_datapacks, get_local_resourcepacks, get_local_shaderpacks, get_log_file_content,
    get_norisk_packs, get_norisk_packs_resolved, get_profile, get_profile_directory_structure,
    get_profile_log_files,
    get_servers_for_profile,
    get_default_memory_max_mb, get_standard_profiles, get_system_ram_mb, get_worlds_for_profile, import_local_mods,
    import_profile, import_world, is_content_installed, is_profile_launching,
    launch_profile, list_profile_backups, list_profile_screenshots, list_profiles, open_profile_folder,
    open_profile_latest_log, preview_import_pack, refresh_norisk_packs, refresh_standard_versions,
    repair_profile,
    get_profile_store_status, reimport_profiles_from_legacy_json,
    resolve_loader_version, restore_profile_backup, search_profiles, set_custom_mod_enabled, set_norisk_mod_status,
    set_profile_mod_enabled, update_datapack_from_modrinth, update_modrinth_mod_version,
    update_profile, update_resourcepack_from_modrinth, update_shaderpack_from_modrinth,
};

// Use statements for registered commands only
use commands::curseforge_commands::{get_curseforge_mods_by_ids, download_and_install_curseforge_modpack_command, get_curseforge_file_changelog_command, get_curseforge_mod_description_command};

use commands::modrinth_commands::{
    check_modrinth_updates, check_mod_updates_unified_command, download_and_install_modrinth_modpack,
    clear_content_cache_command, get_all_modrinth_versions_for_contexts, get_modrinth_tags_command,
    get_modrinth_mod_versions,
    get_modpack_versions_unified_command, get_modrinth_project_details, get_modrinth_project_members,
    get_modrinth_versions_by_hashes, search_modrinth_mods,
    search_modrinth_projects, search_mods_unified_command, get_mod_versions_unified_command,
    switch_modpack_version_command
};

use commands::file_command::{
    delete_file, get_icons_for_archives, get_icons_for_norisk_mods, list_all_mc_logs,
    list_crash_reports, list_launcher_logs, list_process_logs, open_file, open_file_directory,
    read_file_bytes,
    set_file_enabled,
};

// Import config commands
use commands::config_commands::{get_app_version, get_launcher_config, set_launcher_config};
use tauri::{
    menu::{Menu, MenuItem},
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
};

// Import path commands
use commands::path_commands::{get_launcher_directory, resolve_image_path};

// Import cape commands
use commands::cape_command::{
    browse_capes, check_is_moderator, delete_cape, download_template_and_open_explorer, equip_cape,
    get_player_capes, unequip_cape, upload_cape, add_favorite_cape, remove_favorite_cape,
    get_capes_by_hashes, get_owned_capes_list,
};

use commands::cosmetic_command::{
    get_equipped_cosmetics, get_equipped_cosmetics_cached, get_random_local_emote,
};
use commands::icon_command::{
    get_active_creator_code, get_selected_player_icon, get_selected_player_icon_cached,
};

// Import vanilla cape commands
use commands::vanilla_cape_command::{
    get_owned_vanilla_capes, get_currently_equipped_vanilla_cape, equip_vanilla_cape,
    get_vanilla_cape_info, refresh_vanilla_cape_data,
};

// Import Assets commands
use commands::assets_command::get_or_download_asset_model;

// Import NRC commands
use commands::nrc_commands::{check_update_available_command, download_and_install_update_command, get_news_and_changelogs_command};

// Import Content commands
use commands::content_command::{
    bulk_toggle_mod_updates, install_content_to_profile, install_local_content_to_profile,
    switch_content_version, toggle_content_from_profile, toggle_contents_from_profile,
    update_contents_from_profile,
    uninstall_contents_from_profile,
    toggle_mod_updates,
    uninstall_content_from_profile,
};

// Import Java commands
use commands::java_command::{
    detect_java_installations_command, find_best_java_for_minecraft_command, get_java_info_command,
    invalidate_java_cache_command, validate_java_path_command,
};

use commands::friends_command::{
    get_friends, get_pending_requests, get_friends_user, send_friend_request,
    accept_friend_request, deny_friend_request, remove_friend, set_online_status,
    toggle_friend_ping, update_privacy_setting, connect_friends_websocket,
    disconnect_friends_websocket, is_friends_websocket_connected, get_or_create_chat,
    get_private_chats, get_chat_messages, send_chat_message, edit_chat_message,
    delete_chat_message, send_typing_indicator, add_message_reaction,
    remove_message_reaction,
};

#[tokio::main]
async fn main() {
    if let Err(e) = logging::setup_logging().await {
        eprintln!("FEHLER: Logging konnte nicht initialisiert werden: {}", e);
    }

    info!("Starting NoRiskClient Launcher...");

    tauri::Builder::default()
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_updater::Builder::new().build())
        .plugin(tauri_plugin_cli::init())
        .plugin(tauri_plugin_single_instance::init(|app, argv, _cwd| {
            info!("SingleInstance plugin: Second instance triggered with args: {:?}", argv);

            // If the second invocation carried a CLI subcommand we recognize,
            // service it instead of bringing the window to the front.
            if cli::dispatch_hot_start(app, argv.clone()) {
                return;
            }

            match app.get_webview_window("main") {
                Some(window) => {
                    if let Err(e) = window.show() {
                        error!("SingleInstance: Failed to show main window: {}", e);
                    }
                    if let Err(e) = window.unminimize() {
                        error!("SingleInstance: Failed to unminimize main window: {}", e);
                    }
                    if let Err(e) = window.set_focus() {
                        error!("SingleInstance: Failed to focus main window: {}", e);
                    }
                    info!("SingleInstance: Brought existing window to front.");
                }
                None => {
                    info!("SingleInstance: Main window not yet available, still starting up. Ignoring.");
                }
            }
        }))
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_deep_link::init())
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .setup(|app| {
            let app_handle = app.handle().clone();

            // CLI cold-start: handle subcommands (version short-circuits GUI;
            // launch fires asynchronously after State::init completes).
            if cli::dispatch_cold_start(&app_handle) {
                return Ok(());
            }

            // --- Initialize System Tray (Tauri 2.0) ---
            let show_item = MenuItem::with_id(app, "show", "Show NoRisk Launcher", true, None::<&str>)?;
            let quit_item = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&show_item, &quit_item])?;

            let _tray = TrayIconBuilder::new()
                .menu(&menu)
                .show_menu_on_left_click(false)
                .tooltip("NoRisk Client Launcher")
                .icon(app.default_window_icon().unwrap().clone())
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "show" => {
                        match app.get_webview_window("main") {
                            Some(window) => {
                                if let Err(e) = window.show() {
                                    error!("Tray menu: Failed to show window: {}", e);
                                }
                                if let Err(e) = window.unminimize() {
                                    error!("Tray menu: Failed to unminimize window: {}", e);
                                }
                                if let Err(e) = window.set_focus() {
                                    error!("Tray menu: Failed to focus window: {}", e);
                                }
                            }
                            None => {
                                error!("Tray menu: Main window not found - application in inconsistent state");
                            }
                        }
                    }
                    "quit" => {
                        app.exit(0);
                    }
                    _ => {}
                })
                .on_tray_icon_event(|tray, event| match event {
                    TrayIconEvent::Click {
                        button: MouseButton::Left,
                        button_state: MouseButtonState::Up,
                        ..
                    } => {
                        let app = tray.app_handle();
                        match app.get_webview_window("main") {
                            Some(window) => {
                                let is_visible = window.is_visible().unwrap_or(false);
                                let is_minimized = window.is_minimized().unwrap_or(false);

                                if is_visible && !is_minimized {
                                    if let Err(e) = window.hide() {
                                        error!("Tray click: Failed to hide window: {}", e);
                                    }
                                } else {
                                    if let Err(e) = window.show() {
                                        error!("Tray click: Failed to show window: {}", e);
                                    }
                                    if let Err(e) = window.unminimize() {
                                        error!("Tray click: Failed to unminimize window: {}", e);
                                    }
                                    if let Err(e) = window.set_focus() {
                                        error!("Tray click: Failed to focus window: {}", e);
                                    }
                                }
                            }
                            None => {
                                error!("Tray click: Main window not found - application in inconsistent state");
                            }
                        }
                    }
                    TrayIconEvent::DoubleClick {
                        button: MouseButton::Left,
                        ..
                    } => {
                        let app = tray.app_handle();
                        match app.get_webview_window("main") {
                            Some(window) => {
                                if let Err(e) = window.show() {
                                    error!("Tray double-click: Failed to show window: {}", e);
                                }
                                if let Err(e) = window.unminimize() {
                                    error!("Tray double-click: Failed to unminimize window: {}", e);
                                }
                                if let Err(e) = window.set_focus() {
                                    error!("Tray double-click: Failed to focus window: {}", e);
                                }
                            }
                            None => {
                                error!("Tray double-click: Main window not found - application in inconsistent state");
                            }
                        }
                    }
                    _ => {}
                })
                .build(app)?;

            // --- Deep Link Setup ---
            // Register deep link schemes (needed for dev mode on Windows/Linux)
            if let Err(e) = app.deep_link().register_all() {
                error!("Failed to register deep link schemes: {}", e);
            } else {
                info!("Deep link schemes registered successfully.");
            }

            // Handle deep links received while app is running
            let deep_link_app_handle = app_handle.clone();
            app.deep_link().on_open_url(move |event| {
                let handle = deep_link_app_handle.clone();
                let urls = event.urls();
                info!("Deep link received: {:?}", urls);
                tauri::async_runtime::spawn(async move {
                    utils::deep_link_utils::handle_deep_link(&handle, urls).await;
                });
            });

            // Handle cold-start deep links (app was launched via deep link)
            if let Ok(Some(urls)) = app.deep_link().get_current() {
                info!("Cold-start deep link detected: {:?}", urls);
                let cold_start_handle = app_handle.clone();
                tauri::async_runtime::spawn(async move {
                    // Small delay to ensure state initialization has started
                    tokio::time::sleep(tokio::time::Duration::from_secs(3)).await;
                    utils::deep_link_utils::handle_deep_link(&cold_start_handle, urls).await;
                });
            }
            // --- End Deep Link Setup ---

            // --- Handle .noriskpack file opening on initial startup (all platforms) ---
            // The single-instance plugin does not handle the *very first* launch with arguments.
            // We still need to check std::env::args() here for that first launch.
            /*info!("Checking for startup file arguments...");
            let startup_args: Vec<String> = std::env::args().collect();
            if startup_args.len() > 1 { // args[0] is exe path, check if there are more
                let handle_clone = app_handle.clone();
                tauri::async_runtime::spawn(async move {
                    // Pass all startup_args; handle_noriskpack_file_paths will skip the exe path if needed
                    norisk_packs::handle_noriskpack_file_paths(&handle_clone, startup_args).await;
                });
            }*/
            // --- End .noriskpack handling on startup ---

            // Task for State Init and Updater Window
            let state_init_app_handle = app_handle.clone();
            tauri::async_runtime::spawn(async move {
                // --- Create Updater Window (but keep hidden initially) ---
                let updater_window = match updater_utils::create_updater_window(&state_init_app_handle).await {
                    Ok(win) => {
                        trace!("Updater window created successfully (initially hidden).");
                        Some(win)
                    }
                    Err(e) => {
                        error!("Failed to create updater window: {}", e);
                        None
                    }
                };

                // --- State Initialization ---
                info!("Initiating state initialization...");
                if let Err(e) = state::state_manager::State::init(Arc::new(state_init_app_handle.clone())).await {
                    error!("CRITICAL: Failed to initialize state: {}", e);
                    if let Some(win) = updater_window {
                        updater_utils::emit_status(&state_init_app_handle, "close", "Closing due to state init error.".to_string(), None);
                        tokio::time::sleep(tokio::time::Duration::from_millis(200)).await;
                        if let Err(close_err) = win.close() {
                            error!("Failed to close updater window after state init error: {}", close_err);
                        }
                    }
                    {
                        use tauri_plugin_dialog::{
                            DialogExt, MessageDialogButtons, MessageDialogKind,
                        };

                        let reset = state_init_app_handle
                            .dialog()
                            .message(
                                [
                                    "The NoRisk Launcher could not start.".to_string(),
                                    String::new(),
                                    e.to_string(),
                                    String::new(),
                                    "If that does not help:".to_string(),
                                    concat!(
                                        "\"Reset database and restart\" keeps the old ",
                                        "database as app.db.broken.<time> and restores ",
                                        "your profiles from profiles.json.migrated."
                                    )
                                    .to_string(),
                                    String::new(),
                                    "Support: https://discord.norisk.gg".to_string(),
                                ]
                                .join("\n"),
                            )
                            .kind(MessageDialogKind::Error)
                            .title("NoRisk Launcher - Startup Failed")
                            .buttons(MessageDialogButtons::OkCancelCustom(
                                "Reset database and restart".to_string(),
                                "Quit".to_string(),
                            ))
                            .blocking_show();

                        if reset {
                            match state::db::quarantine_database().await {
                                Ok(moved) => {
                                    info!("Database moved aside to {:?}, restarting", moved);
                                    state_init_app_handle.restart();
                                }
                                Err(err) => {
                                    error!("Could not move the database aside: {}", err);
                                    let _ = state_init_app_handle
                                        .dialog()
                                        .message(format!("{}", err))
                                        .kind(MessageDialogKind::Error)
                                        .title("NoRisk Launcher - Reset Failed")
                                        .blocking_show();
                                }
                            }
                        }
                    }
                    std::process::exit(1);
                }
                info!("State initialization finished successfully.");

                // Sweep last session's throwaway temp profiles into the trash
                // (non-blocking, best-effort). The trash's purge_expired retention
                // then deletes them for good. See utils::trash_utils.
                tauri::async_runtime::spawn(async {
                    utils::trash_utils::reap_temp_profiles().await;
                });

                tauri::async_runtime::spawn(async {
                    if let Err(e) =
                        commands::skin_render_command::prune_skin_renders(30).await
                    {
                        log::warn!("Failed to prune skin renders: {}", e);
                    }
                });

                // Issue #130: recover disk from pre-fix runaway logs.
                tauri::async_runtime::spawn(async {
                    utils::log_archive::cleanup_oversized_logs().await;
                });

                // Issue #242: drop stale/orphan cached jars (debounced, best-effort).
                tauri::async_runtime::spawn(async {
                    utils::mod_cache_cleanup::run_startup_cleanup().await;
                });

                #[cfg(windows)]
                commands::clip_commands::start_on_launch(state_init_app_handle.clone());

                trace!("Attempting to retrieve launcher configuration for update check...");
                match state::state_manager::State::get().await {
                    Ok(state_manager_instance) => {
                        let config = state_manager_instance.config_manager.get_config().await;
                        let check_beta_channel = config.check_beta_channel;
                        let mut auto_check_updates_enabled = config.auto_check_updates;

                        // Disable auto-updates when running in Flatpak
                        if updater_utils::is_flatpak() {
                            info!("Running in Flatpak environment - disabling automatic updates (Flatpak handles updates through its own mechanism).");
                            auto_check_updates_enabled = false;
                        }

                        if auto_check_updates_enabled {
                            trace!("Initiating application update check (Channel determined by config: Beta={})...", check_beta_channel);
                            updater_utils::check_for_updates(state_init_app_handle.clone(), check_beta_channel, updater_window.clone()).await;
                            trace!("Update check process has finished.");
                        } else {
                            info!("Auto-check for updates is disabled in settings. Skipping update check.");
                            // Ensure the updater window (if created) is closed if we skip the check.
                            if let Some(win) = updater_window {
                                updater_utils::emit_status(&state_init_app_handle, "close", "Auto-update disabled.".to_string(), None);
                                tokio::time::sleep(tokio::time::Duration::from_millis(200)).await; // Give time for emit to process
                                if let Err(close_err) = win.close() {
                                    error!("Failed to close updater window when skipping updates: {}", close_err);
                                }
                            }
                        }
                    }
                    Err(e) => {
                        error!("Failed to get global state for update check: {}.", e);
                        if let Some(win) = updater_window {
                            updater_utils::emit_status(&state_init_app_handle, "close", "Closing due to state fetch error.".to_string(), None);
                            tokio::time::sleep(tokio::time::Duration::from_millis(200)).await;
                            if let Err(close_err) = win.close() {
                                error!("Failed to close updater window after state fetch error: {}", close_err);
                            }
                        }
                    }
                }

                info!("Updater process finished. Attempting to show main window...");
                if let Some(main_window) = state_init_app_handle.get_webview_window("main") {
                    match main_window.show() {
                        Ok(_) => {
                            info!("Main window shown successfully.");
                            if let Err(e) = main_window.set_focus() {
                                error!("Failed to focus main window (non-critical): {}", e);
                            }
                        }
                        Err(e) => {
                            error!("CRITICAL: Failed to show main window: {}", e);

                            #[cfg(target_os = "windows")]
                            {
                                use tauri_plugin_dialog::{DialogExt, MessageDialogKind};
                                let _ = state_init_app_handle
                                    .dialog()
                                    .message("The NoRisk Launcher encountered a critical error.\n\n\
                                        Please join our Discord for support:\n\
                                        https://discord.norisk.gg")
                                    .kind(MessageDialogKind::Error)
                                    .title("NoRisk Launcher - Critical Error")
                                    .blocking_show();
                            }

                            std::process::exit(1);
                        }
                    }
                } else {
                    error!("CRITICAL: Could not get main window handle!");

                    #[cfg(target_os = "windows")]
                    {
                        use tauri_plugin_dialog::{DialogExt, MessageDialogKind};
                        let _ = state_init_app_handle
                            .dialog()
                            .message("The NoRisk Launcher encountered a critical error.\n\n\
                                Please join our Discord for support:\n\
                                https://discord.norisk.gg")
                            .kind(MessageDialogKind::Error)
                            .title("NoRisk Launcher - Critical Error")
                            .blocking_show();
                    }

                    std::process::exit(1);
                }

                // --- Test Unified Mod Search ---
                //debug_utils::debug_unified_mod_search().await;

                // --- Test Unified Mod Versions ---
                //debug_utils::debug_unified_mod_versions().await;
            });

            // --- Register Focus Event Listener for Discord RPC ---
            if let Some(main_window) = app.get_webview_window("main") {
                let focus_app_handle = app_handle.clone();
                main_window.listen("tauri://focus", move |_event| {
                    let _listener_app_handle = focus_app_handle.clone();
                    tokio::spawn(async move {
                        trace!("Main window focus event received. Triggering DiscordManager handler.");
                        match state::state_manager::State::get().await {
                            Ok(state_manager_instance) => {
                                if let Err(e) = state_manager_instance.discord_manager.handle_focus_event().await {
                                    error!("Error during DiscordManager focus handling: {}", e);
                                }
                            }
                            Err(e) => {
                                error!("Focus event listener: Failed to get global state using State::get(): {}", e);
                            }
                        }
                    });
                });

                // --- Handle window close request (from taskbar, etc.) ---
                main_window.listen("tauri://close-requested", move |_event| {
                    info!("Window close requested via system (taskbar, etc.). Exiting application.");
                    std::process::exit(0);
                });
            } else {
                error!("Could not get main window handle to attach focus listener!");
            }

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            utils::mod_cache_cleanup::debug_list_expected_cache_filenames,
            utils::mod_cache_cleanup::clean_mod_cache_command,
            list_system_fonts,
            create_profile,
            get_profile,
            update_profile,
            delete_profile,
            repair_profile,
            resolve_loader_version,
            list_profiles,
            list_profile_backups,
            restore_profile_backup,
            get_profile_store_status,
            reimport_profiles_from_legacy_json,
            search_profiles,
            get_minecraft_versions,
            launch_profile,
            abort_profile_launch,
            is_profile_launching,
            get_processes,
            get_process,
            get_processes_by_profile,
            stop_process,
            open_minecraft_log_window,
            open_single_log_window,
            focus_main_window,
            begin_login,
            cancel_login,
            is_flatpak,
            remove_account,
            get_active_account,
            set_active_account,
            get_accounts,
            search_modrinth_mods,
            search_modrinth_projects,
            search_mods_unified_command,
            get_mod_versions_unified_command,
            get_modpack_versions_unified_command,
            get_curseforge_mods_by_ids,
            download_and_install_curseforge_modpack_command,
            get_curseforge_file_changelog_command,
            get_curseforge_mod_description_command,
            get_modrinth_mod_versions,
            add_modrinth_mod_to_profile,
            add_modrinth_content_to_profile,
            get_modrinth_project_details,
            get_modrinth_project_members,
            check_modrinth_updates,
            check_mod_updates_unified_command,
            get_icons_for_archives,
            set_profile_mod_enabled,
            delete_mod_from_profile,
            get_norisk_packs,
            get_norisk_packs_resolved,
            set_norisk_mod_status,
            update_modrinth_mod_version,
            get_all_modrinth_versions_for_contexts,
            get_process_log_cursor,
            fetch_crash_report,
            get_custom_mods,
            get_local_resourcepacks,
            get_local_shaderpacks,
            get_local_datapacks,
            set_custom_mod_enabled,
            import_local_mods,
            get_system_ram_mb,
            get_default_memory_max_mb,
            delete_custom_mod,
            open_profile_folder,
            import_profile,
            preview_import_pack,
            upload_log_to_mclogs_command,
            get_fabric_loader_versions,
            get_forge_versions,
            get_neoforge_versions,
            get_quilt_loader_versions,
            set_file_enabled,
            delete_file,
            get_icons_for_norisk_mods,
            open_file_directory,
            download_and_install_modrinth_modpack,
            get_standard_profiles,
            get_profile_directory_structure,
            copy_profile,
            export_profile,
            get_launcher_config,
            set_launcher_config,
            get_launcher_directory,
            resolve_image_path,
            commands::path_commands::upload_profile_images,
            update_resourcepack_from_modrinth,
            update_shaderpack_from_modrinth,
            update_datapack_from_modrinth,
            get_user_skin_data,
            upload_skin,
            reset_skin,
            apply_skin_from_base64,
            get_active_skin,
            get_all_skins,
            get_skin_by_id,
            add_skin,
            remove_skin,
            update_skin_properties,
            set_discord_state,
            browse_capes,
            get_player_capes,
            get_active_creator_code,
            get_selected_player_icon,
            get_selected_player_icon_cached,
            get_equipped_cosmetics,
            get_equipped_cosmetics_cached,
            get_random_local_emote,
            get_owned_capes_list,
            equip_cape,
            delete_cape,
            check_is_moderator,
            upload_cape,
            unequip_cape,
            add_favorite_cape,
            remove_favorite_cape,
            refresh_norisk_packs,
            refresh_standard_versions,
            is_content_installed,
            batch_check_content_installed,
            check_for_group_migration_command,
            open_profile_latest_log,
            detect_java_installations_command,
            get_java_info_command,
            find_best_java_for_minecraft_command,
            invalidate_java_cache_command,
            validate_java_path_command,
            get_worlds_for_profile,
            get_servers_for_profile,
            copy_world,
            import_world,
            check_world_lock_status,
            ping_minecraft_server,
            delete_world,
            get_profile_log_files,
            get_log_file_content,
            list_profile_screenshots,
            list_launcher_logs,
            list_crash_reports,
            list_all_mc_logs,
            list_process_logs,
            open_file,
            read_file_bytes,
            get_app_version,
            get_news_and_changelogs_command,
            check_update_available_command,
            download_and_install_update_command,
            get_modrinth_tags_command,
            clear_content_cache_command,
            get_modrinth_versions_by_hashes,
            switch_modpack_version_command,
            uninstall_content_from_profile,
            toggle_content_from_profile,
            toggle_contents_from_profile,
            update_contents_from_profile,
            uninstall_contents_from_profile,
            toggle_mod_updates,
            bulk_toggle_mod_updates,
            install_content_to_profile,
            commands::minecraft_command::get_profile_by_name_or_uuid,
            commands::minecraft_command::add_skin_locally,
            commands::minecraft_command::get_base64_from_skin_source_command,
            commands::file_command::get_image_preview,
            download_template_and_open_explorer,
            get_all_profiles_and_last_played,
            get_local_content,
            install_local_content_to_profile,
            switch_content_version,
            commands::minecraft_command::get_face_avatar,
            commands::skin_render_command::get_cached_skin_render,
            commands::skin_render_command::store_skin_render,
            commands::applixir_command::applixir_show_ad,
            commands::applixir_command::applixir_mint_session,
            commands::applixir_command::get_afkpoints_balance,
            commands::applixir_command::afk_shop_catalog,
            commands::applixir_command::afk_shop_purchase,
            commands::applixir_command::afk_daily_state,
            commands::applixir_command::afk_daily_claim,
            commands::nrc_commands::discord_auth_link,
            commands::nrc_commands::discord_auth_status,
            commands::nrc_commands::discord_auth_unlink,
            commands::nrc_commands::github_auth_link,
            commands::nrc_commands::github_auth_status,
            commands::nrc_commands::github_auth_unlink,
            commands::nrc_commands::check_crash_log_command,
            commands::crash_fix_command::apply_crash_fix,
            commands::crash_fix_command::revert_crash_fix,
            commands::nrc_commands::log_message_command,
            commands::flagsmith_commands::set_blocked_mods_config,
            commands::flagsmith_commands::get_blocked_mods_config,
            commands::flagsmith_commands::is_filename_blocked,
            commands::flagsmith_commands::is_mod_id_blocked,
            commands::flagsmith_commands::is_modrinth_project_id_blocked,
            commands::flagsmith_commands::refresh_blocked_mods_config,
            commands::pack_rollout_commands::set_pack_rollout_config,
            commands::pack_rollout_commands::get_pack_rollout_config,
            commands::pack_rollout_commands::get_pack_rollout_status,
            commands::pack_rollout_commands::get_effective_pack_id,
            commands::pack_rollout_commands::is_pack_rollout_active,
            commands::pack_rollout_commands::is_pack_aliased,
            commands::pack_fallback_commands::set_pack_fallback_config,
            commands::pack_fallback_commands::get_pack_fallback_config,
            commands::permission_commands::refresh_permissions,
            commands::permission_commands::get_cached_permissions,
            commands::permission_commands::has_permission,
            commands::tester_command::fetch_tester_queue_count,
            commands::tester_command::fetch_tester_queue,
            commands::tester_command::submit_tester_vote,
            commands::tester_command::open_tester_window,
            commands::nrc_commands::get_mobile_app_token,
            commands::nrc_commands::reset_mobile_app_token,
            commands::nrc_commands::get_advent_calendar_command,
            commands::nrc_commands::claim_advent_calendar_day_command,
            commands::nrc_commands::get_unique_players_24h_command,
            commands::nrc_commands::get_referral_info,
            commands::nrc_commands::get_notifications,
            commands::nrc_commands::mark_all_notifications_read,
            commands::nrc_commands::mark_notification_read,
            get_capes_by_hashes,
            get_owned_vanilla_capes,
            get_currently_equipped_vanilla_cape,
            equip_vanilla_cape,
            get_vanilla_cape_info,
            refresh_vanilla_cape_data,
            track_analytics_event,
            commands::analytics_command::get_system_os_info,
            commands::profile_command::launch_profile_with_overrides,
            commands::profile_command::launch_temp_profile,
            commands::profile_command::add_profile_symlink,
            commands::profile_command::remove_profile_symlink,
            commands::profile_command::get_profile_symlinks,
            commands::sync_pack_command::get_or_create_default_sync_pack,
            commands::sync_pack_command::add_dropped_sync_target,
            commands::sync_pack_command::list_sync_seed_candidates,
            commands::sync_pack_command::preview_profile_sync,
            commands::sync_pack_command::get_sync_packs,
            commands::sync_pack_command::get_sync_pack,
            commands::sync_pack_command::create_sync_pack,
            commands::sync_pack_command::update_sync_pack,
            commands::sync_pack_command::import_sync_pack_icon,
            commands::sync_pack_command::add_sync_pack_target,
            commands::sync_pack_command::count_sync_pack_target_users,
            commands::sync_pack_command::remove_sync_pack_target,
            commands::sync_pack_command::add_content_to_sync_pack,
            commands::sync_pack_command::remove_content_from_sync_pack,
            commands::sync_pack_command::remove_mod_from_sync_pack,
            commands::sync_pack_command::get_sync_pack_local_jars,
            commands::sync_pack_command::remove_sync_pack_local_jar,
            commands::sync_pack_command::get_sync_pack_subscribers,
            commands::sync_pack_command::open_sync_pack_folder,
            commands::sync_pack_command::delete_sync_pack,
            commands::sync_pack_command::set_profile_sync_packs,
            commands::sync_pack_command::get_profile_sync_conflicts,
            commands::sync_pack_command::sync_profile_now,
            commands::sync_pack_command::set_sync_pack_mod_enabled,
            commands::sync_pack_command::remove_sync_pack_entries,
            commands::sync_pack_command::set_sync_pack_mods_enabled,
            commands::sync_pack_command::set_sync_pack_mod_version_override,
            commands::sync_pack_command::get_sync_pack_mod_matrix,
            commands::sync_pack_command::resolve_sync_pack_mod,
            commands::launcher_import_command::scan_external_launchers,
            commands::launcher_import_command::add_external_launcher_root,
            commands::launcher_import_command::list_external_instances,
            commands::launcher_import_command::preview_external_instance,
            commands::launcher_import_command::import_external_instance,
            commands::launcher_import_command::cancel_external_import,
            commands::profile_command::get_profile_instance_path,
            commands::profile_command::get_default_profile_path,
            commands::profile_command::get_profile_disk_size,
            get_or_download_asset_model,
            get_friends,
            get_pending_requests,
            get_friends_user,
            send_friend_request,
            accept_friend_request,
            deny_friend_request,
            remove_friend,
            set_online_status,
            toggle_friend_ping,
            update_privacy_setting,
            connect_friends_websocket,
            disconnect_friends_websocket,
            is_friends_websocket_connected,
            get_or_create_chat,
            get_private_chats,
            get_chat_messages,
            send_chat_message,
            edit_chat_message,
            delete_chat_message,
            send_typing_indicator,
            add_message_reaction,
            remove_message_reaction,
            commands::deep_link_handler::confirm_auth_bridge,
            commands::clip_commands::capture_apply_settings,
            commands::clip_commands::capture_release_hotkeys,
            commands::clip_commands::capture_status,
            commands::clip_commands::capture_supported,
            commands::capture_permissions::capture_permissions,
            commands::capture_permissions::capture_open_permission_settings,
            commands::clip_commands::capture_encoder_capabilities,
            commands::clip_commands::capture_show_overlay,
            commands::clip_commands::capture_hide_overlay,
            commands::clip_commands::clip_list,
            commands::clip_commands::clip_storage_usage,
            commands::clip_commands::clip_delete,
            commands::clip_commands::clip_reveal,
            commands::clip_commands::clip_trim,
            commands::clip_commands::clip_details,
            commands::clip_commands::clip_set_favourite,
            commands::clip_commands::clip_open_apps,
            commands::clip_commands::clip_save_thumbnail,
            commands::clip_commands::clip_export_vertical,
            commands::clip_commands::clip_prepare_preview,
            commands::clip_commands::clip_rename,
            commands::clip_commands::clip_open_folder,
        ])
        .build(tauri::generate_context!())
        .expect("error while building tauri application")
        .run(
            #[allow(unused_variables)]
            |app_handle, event| {
                #[cfg(target_os = "macos")]
                if let tauri::RunEvent::ExitRequested { api, code, .. } = event {
                    use std::sync::atomic::{AtomicBool, Ordering};
                    static EXIT_READY: AtomicBool = AtomicBool::new(false);
                    static SHUTTING_DOWN: AtomicBool = AtomicBool::new(false);
                    if !EXIT_READY.load(Ordering::SeqCst) {
                        api.prevent_exit();
                        if !SHUTTING_DOWN.swap(true, Ordering::SeqCst) {
                            let app = app_handle.clone();
                            tauri::async_runtime::spawn(async move {
                                if let Ok(state) = state::State::get().await {
                                    state.capture_supervisor.finish_shutdown().await;
                                }
                                EXIT_READY.store(true, Ordering::SeqCst);
                                app.exit(code.unwrap_or(0));
                            });
                        }
                    }
                }
            },
        );
}
